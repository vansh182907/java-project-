import React, { useState } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useNavigate,
  useLocation,
} from 'react-router-dom';
import { ToastProvider } from './context/ToastContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { WorkoutModal } from './components/workout/WorkoutModal';
import { WorkoutLog } from './types';

// Multi-Route Page Components
import { DashboardPage } from './pages/DashboardPage';
import { WorkoutsPage } from './pages/WorkoutsPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { ChallengesPage } from './pages/ChallengesPage';
import { ProfilePage } from './pages/ProfilePage';
import { CommunityGuidesPage } from './pages/CommunityGuidesPage';
import { AthleteAppLayout } from './components/layout/AthleteAppLayout';

// Admin Space Pages
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminUsersPage } from './pages/AdminUsersPage';
import { AdminModerationPage } from './pages/AdminModerationPage';
import { AdminSettingsPage } from './pages/AdminSettingsPage';

// Protected Route Guard for Authenticated Users
const ProtectedUserRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center gap-3 text-sky-900">
        <div className="w-10 h-10 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-bold tracking-wider uppercase text-sky-600">
          Calibrating Telemetry Access...
        </p>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

// Protected Route Guard for Admin Workspace (RBAC)
const ProtectedAdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, role, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center gap-3 text-sky-900">
        <div className="w-10 h-10 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-bold tracking-wider uppercase text-sky-600">
          Verifying Cryptographic Credentials...
        </p>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/" replace />;
  }

  if (role !== 'ADMIN') {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
};

const AppShell: React.FC = () => {
  const { user, role, isLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isWorkoutModalOpen, setIsWorkoutModalOpen] = useState<boolean>(false);
  const [editingWorkout, setEditingWorkout] = useState<WorkoutLog | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);

  const isAthleteRoute = [
    '/dashboard',
    '/workouts',
    '/analytics',
    '/challenges',
    '/community',
    '/guides',
    '/profile',
  ].some((p) => location.pathname === p || location.pathname.startsWith(p));

  const isAdminRoute = [
    '/admin',
    '/admin/dashboard',
    '/admin/users',
    '/admin/challenges',
    '/admin/moderation',
    '/admin/settings',
    '/admin/activity',
    '/admin/audit',
  ].some((p) => location.pathname === p || location.pathname.startsWith(p));

  const AthleteShell: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <AthleteAppLayout
      onOpenLogWorkout={handleOpenLogWorkout}
      refreshTrigger={refreshTrigger}
    >
      {children}
    </AthleteAppLayout>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex flex-col items-center justify-center gap-3 text-sky-900">
        <div className="w-10 h-10 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-bold tracking-wider uppercase text-sky-600">
          Initializing Clinical Health OS...
        </p>
      </div>
    );
  }

  const handleOpenLogWorkout = () => {
    setEditingWorkout(null);
    setIsWorkoutModalOpen(true);
  };

  const handleEditWorkout = (workout: WorkoutLog) => {
    setEditingWorkout(workout);
    setIsWorkoutModalOpen(true);
  };

  const handleWorkoutSaved = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  const handleNavigateTab = (tab: string) => {
    if (tab === 'analytics') navigate('/analytics');
    else if (tab === 'workouts') navigate('/workouts');
    else if (tab === 'challenges') navigate('/challenges');
    else if (tab === 'profile') navigate('/profile');
    else if (tab === 'guides') navigate('/community');
    else if (tab.startsWith('admin-')) {
      if (tab === 'admin-users') navigate('/admin/users');
      else if (tab === 'admin-content') navigate('/admin/moderation');
      else if (tab === 'admin-settings' || tab === 'admin-audit') navigate('/admin/settings');
      else navigate('/admin/dashboard');
    } else {
      navigate('/dashboard');
    }
  };

  return (
    <div
      className={
        isAthleteRoute || isAdminRoute
          ? 'min-h-screen bg-transparent text-slate-900 flex flex-col selection:bg-sky-500 selection:text-white'
          : 'relative min-h-screen w-full overflow-x-hidden bg-gradient-to-br from-[#EBF5FF] via-[#F3F9FF] to-[#E0F2FE] text-slate-900 flex flex-col selection:bg-sky-500 selection:text-white'
      }
    >
      {/* Background layer for non-athlete/non-admin routes (like Landing Page) */}
      {!isAthleteRoute && !isAdminRoute && (
        <>
          <div 
            className="pointer-events-none fixed inset-0 z-0 opacity-[0.05] mix-blend-multiply bg-cover bg-center bg-no-repeat transition-opacity"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=2000&q=80')`
            }}
          />
          <div 
            className="pointer-events-none fixed inset-0 z-0 opacity-[0.04] bg-[radial-gradient(#0284C7_1px,transparent_1px)] [background-size:24px_24px]"
          />
        </>
      )}

      {/* Persistent Light-Glass Navigation Header (hidden on athlete telemetry & admin routes) */}
      {user && !isAthleteRoute && !isAdminRoute && <Navbar onOpenLogWorkout={handleOpenLogWorkout} />}

      {/* Main Content Area */}
      <main
        className={
          isAthleteRoute || isAdminRoute
            ? 'w-full flex-1'
            : 'relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8'
        }
      >
        <Routes>
          {/* Public Root Route */}
          <Route
            path="/"
            element={
              user ? (
                <Navigate
                  to={role === 'ADMIN' ? '/admin/dashboard' : '/dashboard'}
                  replace
                />
              ) : (
                <LandingPage />
              )
            }
          />

          {/* ================= USER SPACE ROUTES ================= */}
          {/* 1. /dashboard — Daily Pulse View */}
          <Route
            path="/dashboard"
            element={
              <ProtectedUserRoute>
                <AthleteShell>
                  <DashboardPage
                    onOpenLogWorkout={handleOpenLogWorkout}
                    onNavigateTab={handleNavigateTab}
                    refreshTrigger={refreshTrigger}
                  />
                </AthleteShell>
              </ProtectedUserRoute>
            }
          />

          {/* 2. /workouts — Workout Center */}
          <Route
            path="/workouts"
            element={
              <ProtectedUserRoute>
                <AthleteShell>
                  <WorkoutsPage
                    onOpenLogWorkout={handleOpenLogWorkout}
                    onEditWorkout={handleEditWorkout}
                    refreshTrigger={refreshTrigger}
                  />
                </AthleteShell>
              </ProtectedUserRoute>
            }
          />

          {/* 3. /analytics — 3D Metrics & Progress */}
          <Route
            path="/analytics"
            element={
              <ProtectedUserRoute>
                <AthleteShell>
                  <AnalyticsPage />
                </AthleteShell>
              </ProtectedUserRoute>
            }
          />

          {/* 4. /challenges — Arena & Badges */}
          <Route
            path="/challenges"
            element={
              <ProtectedUserRoute>
                <AthleteShell>
                  <ChallengesPage
                    onChallengeJoined={() => setRefreshTrigger((prev) => prev + 1)}
                  />
                </AthleteShell>
              </ProtectedUserRoute>
            }
          />

          {/* 5. /profile — Interactive 3D Profile & Settings */}
          <Route
            path="/profile"
            element={
              <ProtectedUserRoute>
                <AthleteShell>
                  <ProfilePage />
                </AthleteShell>
              </ProtectedUserRoute>
            }
          />

          {/* Optional: /community & /guides */}
          <Route
            path="/community"
            element={
              <ProtectedUserRoute>
                <AthleteShell>
                  <CommunityGuidesPage />
                </AthleteShell>
              </ProtectedUserRoute>
            }
          />
          <Route
            path="/guides"
            element={
              <ProtectedUserRoute>
                <Navigate to="/community" replace />
              </ProtectedUserRoute>
            }
          />

          {/* ================= ADMIN SPACE ROUTES ================= */}
          {/* 1. /admin/dashboard — Platform Overview & Telemetry */}
          <Route
            path="/admin/dashboard"
            element={
              <ProtectedAdminRoute>
                <AdminDashboardPage initialTab="overview" />
              </ProtectedAdminRoute>
            }
          />

          {/* 2. /admin/users — Paginated User Directory & Roles */}
          <Route
            path="/admin/users"
            element={
              <ProtectedAdminRoute>
                <AdminDashboardPage initialTab="users" />
              </ProtectedAdminRoute>
            }
          />

          {/* 3. /admin/moderation — Content Approval Queue */}
          <Route
            path="/admin/moderation"
            element={
              <ProtectedAdminRoute>
                <AdminDashboardPage initialTab="moderation" />
              </ProtectedAdminRoute>
            }
          />

          {/* 4. /admin/settings — Global Platform Configuration */}
          <Route
            path="/admin/settings"
            element={
              <ProtectedAdminRoute>
                <AdminDashboardPage initialTab="settings" />
              </ProtectedAdminRoute>
            }
          />

          {/* 5. /admin/challenges — Quest Management */}
          <Route
            path="/admin/challenges"
            element={
              <ProtectedAdminRoute>
                <AdminDashboardPage initialTab="challenges" />
              </ProtectedAdminRoute>
            }
          />

          {/* 6. /admin/activity & /admin/audit — Security Audit Trail */}
          <Route
            path="/admin/activity"
            element={
              <ProtectedAdminRoute>
                <AdminDashboardPage initialTab="activity" />
              </ProtectedAdminRoute>
            }
          />
          <Route
            path="/admin/audit"
            element={
              <ProtectedAdminRoute>
                <AdminDashboardPage initialTab="activity" />
              </ProtectedAdminRoute>
            }
          />

          {/* Admin legacy alias */}
          <Route
            path="/admin"
            element={<Navigate to="/admin/dashboard" replace />}
          />

          {/* Wildcard Fallback */}
          <Route
            path="*"
            element={
              <Navigate
                to={
                  !user
                    ? '/'
                    : role === 'ADMIN'
                    ? '/admin/dashboard'
                    : '/dashboard'
                }
                replace
              />
            }
          />
        </Routes>
      </main>

      {/* Global Interactive Workout Modal (with 3D Muscle Anatomy Torso Selector) */}
      <WorkoutModal
        isOpen={isWorkoutModalOpen}
        onClose={() => setIsWorkoutModalOpen(false)}
        onSaved={handleWorkoutSaved}
        editWorkout={editingWorkout}
      />
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <ToastProvider>
        <AuthProvider>
          <AppShell />
        </AuthProvider>
      </ToastProvider>
    </Router>
  );
}
